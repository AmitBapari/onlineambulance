package com.wedrive.driver.Listeners;

/**
 * Created by Appoets on 03-02-2017.
 */

public interface ConnectionChangeListener {
    void OnMyBooleanChanged();
}
