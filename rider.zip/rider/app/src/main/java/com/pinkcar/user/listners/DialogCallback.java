package com.pinkcar.user.listners;

public interface DialogCallback {
}
