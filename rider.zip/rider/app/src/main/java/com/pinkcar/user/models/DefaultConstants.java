package com.pinkcar.user.models;

public class DefaultConstants {
    public final static long DEFAULT_CONNECTION_TIME_OUT = 60;
    public final static long DEFAULT_READ_TIME_OUT = 60;
    public final static long DEFAULT_WRITE_TIME_OUT = 60;
}
