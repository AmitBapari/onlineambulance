package com.pinkcar.user.models;

public class GetUserRate {

    String request_id;
    String paid;
    String user_rated;
    String provider_id;
    String user_name;
    String provider_name;
    String provider_picture;

    public String getRequest_id() {
        return request_id;
    }

    public void setRequest_id(String request_id) {
        this.request_id = request_id;
    }

    public String getPaid() {
        return paid;
    }

    public void setPaid(String paid) {
        this.paid = paid;
    }

    public String getUser_rated() {
        return user_rated;
    }

    public void setUser_rated(String user_rated) {
        this.user_rated = user_rated;
    }

    public String getProvider_id() {
        return provider_id;
    }

    public void setProvider_id(String provider_id) {
        this.provider_id = provider_id;
    }

    public String getUser_name() {
        return user_name;
    }

    public void setUser_name(String user_name) {
        this.user_name = user_name;
    }

    public String getProvider_name() {
        return provider_name;
    }

    public void setProvider_name(String provider_name) {
        this.provider_name = provider_name;
    }

    public String getProvider_picture() {
        return provider_picture;
    }

    public void setProvider_picture(String provider_picture) {
        this.provider_picture = provider_picture;
    }
}
